import mongoose, { Schema } from "mongoose";

const employeeSchema = new Schema(
  {
    email: String,
    fullname: String,
    salary: Number,
    avatar: String,
  },
  {
    timestamps: true,
  }
);

const Employee =
  mongoose.models.Employee || mongoose.model("Employee", employeeSchema);
export default Employee;
