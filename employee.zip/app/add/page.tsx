import AddUser from "../components/AddUser";

export default function Add() {
  return <AddUser />;
}
