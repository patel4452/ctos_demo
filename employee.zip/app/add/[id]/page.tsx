import EditUser from "@/app/components/EditUser";

export default function Edit() {
  return <EditUser />;
}
